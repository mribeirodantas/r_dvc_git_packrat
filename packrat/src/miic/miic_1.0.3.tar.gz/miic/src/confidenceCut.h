#include "structure.h"
#include <vector>
#include <string>

std::vector < std::vector<std::string > > confidenceCut(Environment&);
