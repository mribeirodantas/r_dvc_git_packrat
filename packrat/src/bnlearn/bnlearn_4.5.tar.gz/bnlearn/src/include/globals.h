
/* the global test counter, now living in C-land, and other symbols. */
extern double test_counter;
extern SEXP BN_ModelstringSymbol;
extern SEXP BN_NodesSymbol;
extern SEXP BN_ProbSymbol;
extern SEXP BN_MethodSymbol;
extern SEXP BN_WeightsSymbol;
extern SEXP BN_DsepsetSymbol;
extern SEXP TRUESEXP, FALSESEXP;

/* numerical constants */
#define MACHINE_TOL sqrt(DOUBLE_EPS)

